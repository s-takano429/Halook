var HDFSView = wgp.AbstractView.extend({
	initialize : function (){
		this.viewType = wgp.constants.VIEW_TYPE.VIEW;
		this.collection = new HDFSViewCollection();
		this.attributes = {};
		this.registerCollectionEvent();
		console.log('called initialize hdfs view');
		this.
	},
	
	render : function(){
		console.log('call render hdfs view ');
	},
	
	onAdd : function(element){
		//////////////
		///datenodeの使用容量
		//////////////		
		var dn = [];
		var data = element.attributes.data;
		var numDataNode = element.attributes.data.length;
		for(var i=0; i<numDataNode; i++){
			dn[i] = {
				    type:wgp.constants.CHANGE_TYPE.ADD,
				    state:wgp.constants.STATE.NORMAL,
				    objectName:"DataNodeRectangle",
				    objectId : data[i].host,
				    width : mainCircleSize.width * Math.PI /numDataNode,
				    height : 0.2 * data[i].size,
				    angle : 360/numDataNode*i,
				    zIndex : 0,
				    centerX : viewArea2.width/2,
				    centerY : viewArea2.height/2,
				    radius : mainCircleSize.width/2
			};
		}
		var mapDataInterval = function(windowId){
			function innerFunction(){
				var addData = [{
				    windowId:windowId,
				    data:dn
				}];
				appView.notifyEvent(addData);
			};
			return innerFunction;
		};
		this.viewMap[element.get("objectId")] = new xxxView();
	},
	
	onChange : function(element){
		console.log('call onChange hdfs view '+this.collection);
	},
	
	onRemove : function(element){
		var target = this.viewMap[element.get("objectId")];
		target.remove();
		this.viewMap[element.get("objectId")] = null;
	}
});