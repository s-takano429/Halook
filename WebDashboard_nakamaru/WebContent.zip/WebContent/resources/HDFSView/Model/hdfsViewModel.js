var HDFSViewModel = Backbone.Model.extend({
	defaults:{
		timestamp : "",
		data : [],
		event : []
	},
	idAttribute:"timestamp"
});

var HDFSViewCollection = Backbone.Collection.extend({
	model : HDFSViewModel
});